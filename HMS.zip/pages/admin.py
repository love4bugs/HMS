from django.contrib import admin
from .models import *

admin.site.register(Room)
admin.site.register(Checkout)
admin.site.register(Costumer)
admin.site.register(Item)
admin.site.register(RestaurantParchase)
admin.site.register(Gym)
admin.site.register(Pool)
admin.site.register(GymUsage)
admin.site.register(PoolUsage)